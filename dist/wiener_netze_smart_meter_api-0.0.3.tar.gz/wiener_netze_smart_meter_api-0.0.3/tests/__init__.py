# SPDX-FileCopyrightText: 2025-present tschoerk <tschoerk@proton.me>
#
# SPDX-License-Identifier: MIT
