# SPDX-FileCopyrightText: 2025-present tschoerk <tschoerk@proton.me>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.6"
